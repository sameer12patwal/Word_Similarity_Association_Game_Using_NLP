var g_classes;
var g_words;
var g_counter = -1;

var routeArray;
var k=-1;
var setVisualsInitialized=0;


var sets=new Array();

//var req="http://cs.uef.fi/mopsi_dev/routes/server.php?param={%22request_type%22:%22get_reduced_routes_per_sets%22,%22routes%22:[{%22route_id%22:%221415361549849%22,%22user_id%22:%22260%22,%22set%22:%220%22},{%22route_id%22:%221415346522753%22,%22user_id%22:%22260%22,%22set%22:%221%22},{%22route_id%22:%221414934997812%22,%22user_id%22:%22260%22,%22set%22:%220%22},{%22route_id%22:%221414929842580%22,%22user_id%22:%22260%22,%22set%22:%221%22},{%22route_id%22:%221414917184425%22,%22user_id%22:%22260%22,%22set%22:%222%22},{%22route_id%22:%221414849687615%22,%22user_id%22:%22260%22,%22set%22:%220%22},{%22route_id%22:%221414594904951%22,%22user_id%22:%22260%22,%22set%22:%220%22},{%22route_id%22:%221414219929122%22,%22user_id%22:%22260%22,%22set%22:%223%22},{%22route_id%22:%221413868264961%22,%22user_id%22:%22260%22,%22set%22:%22undefined%22},{%22route_id%22:%221413777171826%22,%22user_id%22:%22260%22,%22set%22:%22undefined%22}]}"

var draggedElement=null;
var currentMousePos={ x: -1, y: -1 };
var routesLoaded=false;
var mapLoaded=false;

var map;
$(document).ready(function()
{
	//var result=jQuery.parseJSON(pageParams);
	var routes=pageParams.routes;
	routeArray=new Array();
	
	emptySets();
	for(var i=0;i<routes.length;i++){
		
		routeArray[routes[i]["user_id"]+"_"+routes[i]["route_id"]]={overlap:-1, offset:i, reducedPath:routes[i]["reducedPath"]};
		//routeArray[routes[i]["user_id"]+"_"+routes[i]["route_id"]]["reducedPath"]=routes[i]["reducedPath"];
		var setIndex=(Number)(routes[i]["set"]);
		if(isNaN(setIndex)){
			setIndex=0;
		}
		k=Math.max(k,setIndex+1);
		//k=10;
		if(sets[routes[i]["set"]]==null){
			sets[routes[i]["set"]]=new Array();
			sets[routes[i]["set"]]["routes"]=new Array();
		}
		sets[routes[i]["set"]]["routes"].push(routes[i]["user_id"]+"_"+routes[i]["route_id"]);
	}
	for(var i in routeArray){
		routeArray[i]["offset"]=Math.PI/2+3*Math.PI/2*routeArray[i]["offset"]/routes.length;;
	}
	routesLoaded=true;
	if(mapLoaded==true){
		drawRoutesToMap();
	}
	
	google.maps.event.addDomListener(window, 'load', initializeMap);

	$(document).mousemove(function(event) {
        currentMousePos.x = event.pageX;
        currentMousePos.y = event.pageY;
    });

	
	
	//fillSets();
	drawSets();
});

function fillSets(){
	emptySets();
	var cnt=0;
	for(var i in routeArray){
		sets[cnt%k].push(i);
		cnt++;
	}
}
function drawSets(){
	for(var i=0;i<sets.length;i++){
		var set=sets[i];
		
		set["X"]=$(window).width()/2+(Math.cos(Math.PI+Math.PI*2*i/sets.length))*($(window).width()/2-200);
		set["Y"]=$(window).height()/2+(Math.sin(Math.PI+Math.PI*2*i/sets.length))*($(window).height()/2-120);
		set["index"]=i;
		if(setVisualsInitialized<k){
			var newDiv=document.createElement("div");
			$(newDiv).attr("id","s_"+i);
			$(newDiv).addClass("largeCircle");
			$(newDiv).mouseover(showSet);			
			$("#container").append(newDiv);
			
			
			var newDiv2=document.createElement("div");
			$(newDiv2).attr("id","t_"+i);
			$(newDiv2).addClass("overlapText");
			$(newDiv2).css("left",set["X"]);
			$(newDiv2).css("top",set["Y"]);
			$("#container").append(newDiv2);
			//
			$(newDiv).css("left",set["X"]);
			$(newDiv).css("top",set["Y"]);
		}
		
		
		queryNovelty(set);

		
	}
	
	if(setVisualsInitialized<k){
		var newDiv2=document.createElement("div");
		$(newDiv2).attr("id","meanOverlap");
		$(newDiv2).css("position","overlap");
		$(newDiv2).css("background","white");
			$(newDiv2).addClass("overlapText");
			
		$(newDiv2).css("left","70px");
		$(newDiv2).css("top","0px");
		/*$(newDiv2).css("left",set["X"]);
		$(newDiv2).css("top",set["Y"]);*/
		$("#container").append(newDiv2);
	}
}

function onDragEndFunction(e){
	removeFromRespectiveSet(this.id);
	
	
	for(var k=0;k<sets.length;k++){
		if(Draggable.get($("#"+this.id)).hitTest($("#s_"+k))){
			sets[k]["routes"].push(this.id);
			break;
		}
	}
	
	var transform=$("#"+this.id).css("transform");
	$("#"+this.id).remove();
	var newDiv=document.createElement("div");
	$(newDiv).attr("id",this.id);
	$(newDiv).addClass("circle");
	$(newDiv).mouseover(showRoute);
	$(newDiv).css("left",currentMousePos.x);
	$(newDiv).css("top",currentMousePos.y);
	$("#container").append(newDiv);
	
	Draggable.create($("#"+this.id), {type:"x,y", edgeResistance:0.65, bounds:"#container"});
	Draggable.get($("#"+this.id)).addEventListener("dragend", onDragEndFunction);
	
	
	drawSets();
	
}

function removeFromRespectiveSet(id){
	for(var i=0;i<sets.length;i++){
		for(var j=0;j<sets[i]["routes"].length;j++){
			if(sets[i]["routes"][j]==id){
				sets[i]["routes"].splice(j,1);
				return;
			}
		}
	}
}

function emptySets(){
	sets=new Array();
	for(var i=0;i<k;i++){
		sets[i]=new Array();
	}
}
function makeBackground(sample){
	var background=new Array();
	for(var i=0;i<sample.length;i++){
		for(var j=0;j<sample[i].length;j++){
			background[sample[i][j].hashCode]=true;
		}
	}
	return background;
}
/*
rt.js:30 260_1414917184425
rt.js:30 260_1414929842580
rt.js:30 260_1414934997812
rt.js:30 260_1415346522753
rt.js:30 260_1415361549849
rt.js:30 260_1415548754315
*/
function novelty(route, background){
	var novelty=route.length;
	for(var i=0;i<route.length;i++){
		if(background[route[i].hashCode]==true){
			novelty--;
		}
	}
	return novelty/route.length;
}
function queryNovelty(set){
	var routes=new Array();
	for(var i=0;i<set["routes"].length;i++){
		var element=set["routes"][i].split("_");
		routes.push({"user_id":element[0],"route_id":element[1]});
	}
	console.log('http://cs.uef.fi/mopsi_dev/routes/server.php?param={"request_type":"get_novelties","routes":'+JSON.stringify(routes) +'}');
	$.get('http://cs.uef.fi/mopsi_dev/routes/server.php?param={"request_type":"get_novelties","routes":'+JSON.stringify(routes) +'}', function(data){
	
		var novelties=jQuery.parseJSON(data);
		novelties=jQuery.parseJSON(novelties);
		
		var totalOverlap=0;
		for(var j=0;j<set["routes"].length;j++){
			/*var sample=new Array();
			for(var k=0;k<set.length;k++){
				if(k!=j){
					sample.push(routeArray[set[k]]["cells"]);
				}
			}*/
			//var background=makeBackground(sample);
			routeArray[set["routes"][j]]["overlap"]=1-novelties[set["routes"][j]];
			
			totalOverlap+=routeArray[set["routes"][j]]["overlap"];
			if(setVisualsInitialized<k){
				var newDiv=document.createElement("div");
				$(newDiv).attr("id",""+set["routes"][j]);
				$(newDiv).addClass("circle");
				
				$(newDiv).mouseover(showRoute);
				$("#container").append(newDiv);
				//
				Draggable.create($("#"+set["routes"][j]), {type:"x,y", edgeResistance:0.65, bounds:"#container"});
				
				
				Draggable.get($("#"+set["routes"][j])).addEventListener("dragend", onDragEndFunction);
			}
			
			 TweenLite.to($("#"+set["routes"][j]), 2, {left:set["X"]+Math.cos(routeArray[set["routes"][j]]["offset"])*routeArray[set["routes"][j]]["overlap"]*100, 
				top:set["Y"]+Math.sin(routeArray[set["routes"][j]]["offset"])*routeArray[set["routes"][j]]["overlap"]*100});
			 
		}
		if(set["routes"].length==0){
			$("#"+"t_"+set["index"]).html('');
		}else{
			totalOverlap/=set["routes"].length;
			$("#"+"t_"+set["index"]).html(totalOverlap.toFixed(1));
		}
	updateAverageOverlap();
		setVisualsInitialized++;
	});
		
}


function updateAverageOverlap(){
	var averageOverlap=0;
	for(var i=0;i<sets.length;i++){
	  var val=$("#t_"+i).html();
	  if(!isNaN(val)){
		averageOverlap+=(Number)(val);
	  }
	}
	if(sets.length!=0){
	  averageOverlap/=sets.length;
	}
	$("#meanOverlap").html(averageOverlap.toFixed(2));
}
function initialize(classes){
	
	for(var i=0;i<classes.length;i++){
		var newDiv=document.createElement("div");
		$(newDiv).html(classes[i]["value"]);
		$(newDiv).css("position","absolute");
		
	$(newDiv).css("text-align","center");
		$(newDiv).css("border","dashed 3px");
		$(newDiv).css("padding-top","20px");
		$(newDiv).css("width","100px");
		$(newDiv).css("height","50px");
		
		$(newDiv).css("background","#DDDDDD");
		$(newDiv).css("font-size","x-large");
		
		$(newDiv).attr("id","class_"+classes[i]["id"]);
		var radius=100;
		
		var w=Math.max($(window).width()/2,260);
		var h=Math.max($(window).height()/2,220);
		$(newDiv).css("left",$(window).width()/2+(Math.cos(Math.PI+Math.PI*2*i/classes.length))*(w-100)-50);
		$(newDiv).css("top",$(window).height()/2+(Math.sin(Math.PI+Math.PI*2*i/classes.length))*(h-100)-50);
		$("#container").append(newDiv);
	}
	
	var newDiv=document.createElement("div");
	$(newDiv).attr("id","word");
	$("#container").append(newDiv);
	showNextWord();

	Draggable.create($("#word"), {type:"x,y", edgeResistance:0.65, bounds:"#container", throwProps:true,
		onDragEnd:function(e) {
			if(g_counter<g_words.length){
				for(var i=0;i<classes.length;i++){
					if(this.hitTest("#class_"+classes[i]["id"])){
						g_words[g_counter]["classId"]=classes[i]["id"];
						if(classes[i]["id"]==g_words[g_counter]["correctClassId"] || g_words[g_counter]["correctClassId"]==-1){
							console.log("CORRECT");
		
							showNextWord();
						}else{
							console.log("INCORRECT");
		
							showNextWord();
						}
					}
				}		
			}else{
			}
		}

	});
}


function showNextWord(){
	g_counter++;
	if(g_counter>=g_words.length){
		for(var i=0;i<g_words.length;i++){
			g_words[i]["wordId"]=g_words[i]["id"];
		}
		$.get('http://cs.uef.fi/paikka/Radu/labeler/serverside/server.php?param={"request_type":"submit_results","name":"radu","results":'+JSON.stringify(g_words) +'}');
		

		
		alert("done");
		Draggable.get($("#word")).kill();
		
		
		return;
	}
	$("#word").html(g_words[g_counter]["value"]);
	$("#word").css("position","absolute");
	
	$("#word").css("text-align","center");
	$("#word").css("width","100px");
	$("#word").css("height","40px");
		$("#word").css("padding-top","10px");
	
	$("#word").css("background","#AAAAFF");
	$("#word").css("font-size","x-large");
	
	$("#word").css("cursor","pointer");
	
	$("#word").css("left",$(window).width()/2-50)
	$("#word").css("top",$(window).height()/2-40);
	
	
}


function initializeMap() {
  var mapOptions = {
    zoom: 3,
    center: new google.maps.LatLng(0, -180),
    mapTypeId: google.maps.MapTypeId.TERRAIN
  };

  map = new google.maps.Map(document.getElementById('map-canvas'),
      mapOptions);

	  
  //var mapWidth=$(window).width()-700;
  //var mapHeight=$(window).height()-500;
  var mapWidth=$(window).width();
  var mapHeight=$(window).height();
  $("#map-canvas").css("width",mapWidth);
  $("#map-canvas").css("height",mapHeight);
  $("#map-canvas").css("margin-left",(-mapWidth/2));
  $("#map-canvas").css("margin-top",(-mapHeight/2));
 
  
  
  mapLoaded=true;
  if(routesLoaded==true){
    drawRoutesToMap();
  }
}

function drawRoutesToMap(){
  for(var i in routeArray){
	var reducedPath=routeArray[i]["reducedPath"];
	var polylineArray=new Array();
	
    var bounds = new google.maps.LatLngBounds();
	for(var j=0;j<reducedPath.length;j++){
	  var point=new google.maps.LatLng(reducedPath[j][0], reducedPath[j][1]);
      polylineArray.push(point);
	  bounds.extend(point);
	}
	
	var polyline = new google.maps.Polyline({
	  path: polylineArray,
	  strokeColor: '#000000',
      strokeWeight: 5
    });

	routeArray[i]["polyline"]=polyline;
	routeArray[i]["bounds"]=bounds;
  }
}

function hideAllRoutes(){
  for(var i in routeArray){
	if(routeArray[i]["polyline"]!=null){
	  routeArray[i]["polyline"].setMap(null);
	  routeArray[i]["polyline"].setOptions({strokeColor:"#000000"});
	}
  }
}
function showSet(){
  var id=this.id;
  id=id.split("_");
  id=id[1];
  
  hideAllRoutes();
	
  var set=sets[id]["routes"];
  
  
  var bounds=null;
  for(var i=0;i<set.length;i++){
	if(routeArray[set[i]]["polyline"]!=null){
	  routeArray[set[i]]["polyline"].setMap(map);
	  
	  if(bounds==null){
		bounds = new google.maps.LatLngBounds(
			routeArray[set[i]]["bounds"].getSouthWest(),
			routeArray[set[i]]["bounds"].getNorthEast());
	  }else{
		bounds.union(routeArray[set[i]]["bounds"]);
	  }
	}
  }
  
  if(bounds!=null){
	map.fitBounds(bounds);	
  }
}

var nextZIndex=1000;
function showRoute(){
  var id=this.id;
  
  //hideAllRoutes();
	
  
  if(routeArray[id]["polyline"]!=null){
	routeArray[id]["polyline"].setMap(map);
	routeArray[id]["polyline"].setOptions({strokeColor:"#FF0000",zIndex:nextZIndex});
	nextZIndex++;
	//map.fitBounds(routeArray[id]["bounds"]);	
  }
 
  
}