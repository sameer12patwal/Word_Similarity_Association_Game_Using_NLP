var g_classes;
var g_words;
var g_counter=-1;
var startTime;
var g_incorrect=0;
function initialize(classes){
	for(var i=0;i<classes.length;i++){
		var newDiv=document.createElement("div");
		$(newDiv).html(classes[i]["value"]);
		$(newDiv).css("position","absolute");
		
	$(newDiv).css("text-align","center");
	    $(newDiv).css("border-radius","50%");
		$(newDiv).css("border","3px solid red");
		$(newDiv).css("padding-top","20px");
		$(newDiv).css("width","150px");
		$(newDiv).css("height","50px");
		
		$(newDiv).css("background","yellow");
		$(newDiv).css("font-size","x-large");
		
		$(newDiv).attr("id","class_"+classes[i]["id"]);
		var radius=100;
		
		var w=Math.max($(window).width()/2,260);
		var h=Math.max($(window).height()/2,220);
		$(newDiv).css("left",$(window).width()/2+(Math.cos(Math.PI+Math.PI*2*i/classes.length))*(w-100)-50);
		$(newDiv).css("top",$(window).height()/2+(Math.sin(Math.PI+Math.PI*2*i/classes.length))*(h-100)-50);
		$("#container").append(newDiv);
	}
	
	
	showNextWord(classes);
	
	
	startTime=new Date().getTime();
}


function showNextWord(classes){
	g_counter++;
	if(g_counter>=g_words.length){
		for(var i=0;i<g_words.length;i++){
			g_words[i]["wordId"]=g_words[i]["id"];
		}
		$.get('http://localhost/labeler/serverside/server.php?param={"request_type":"submit_results","name":"Harsh","results":'+JSON.stringify(g_words) +'}');
		
	
		var duration = new Date().getTime()-startTime;
		// the longer the game, the lower the points
		var timeBonus=30000-Math.min(30000,duration);
		var score = 10-g_incorrect;
		var totalScore=score*10+timeBonus/100;
		
		
		Draggable.get($("#word")).kill();
		
		$("#word").remove();
		var newDiv=document.createElement("div");
		$(newDiv).attr("id","word");
		$("#container").append(newDiv);
		
		$("#word").html(totalScore.toFixed(0)+" points!");
		$("#word").css("position","absolute");
		
		$("#word").css("text-align","center");
		$("#word").css("width","100px");
		$("#word").css("height","40px");
			$("#word").css("padding-top","10px");
		
		$("#word").css("font-size","x-large");
		$("#word").css("left",$(window).width()/2-50)
		$("#word").css("top",$(window).height()/2-40);
		
		
		$.playSound('./sounds/tada.wav');
							
		return;
	}
	var lastLeft=$("#word").css("left");
	var lastTop=$("#word").css("top");
	
	//console.log($("#word").left);
	$("#word").remove();
	var newDiv=document.createElement("div");
	$(newDiv).attr("id","word");
	$("#container").append(newDiv);
	
	
	
	Draggable.create($("#word"), {type:"x,y", edgeResistance:0.65, bounds:"#container", throwProps:true,
		onDragEnd:function(e) {
			if(g_counter<g_words.length){
				for(var i=0;i<classes.length;i++){
					if(this.hitTest("#class_"+classes[i]["id"])){
						g_words[g_counter]["classId"]=classes[i]["id"];
						if(classes[i]["id"]==g_words[g_counter]["correctClassId"] || g_words[g_counter]["correctClassId"]==-1){
							console.log("CORRECT");
							$.playSound('./sounds/correct.wav');
							TweenMax.to("#class_"+classes[i]["id"], 0.2, {backgroundColor:"green"});
							TweenMax.to("#class_"+classes[i]["id"], 0.3, {css:{backgroundColor:"yellow"},delay:0.2});
							showNextWord(classes);
						}else{
							console.log("INCORRECT");
							g_incorrect++;
							
							$.playSound('./sounds/wrong.wav');
		
							TweenMax.to("#class_"+classes[i]["id"], 0.2, {backgroundColor:"red"});
							TweenMax.to("#class_"+classes[i]["id"], 0.3, {css:{backgroundColor:"yellow"},delay:0.2});
							showNextWord(classes);
						}
					}
				}		
			}else{
			}
		}

	});
	
	$("#word").html(g_words[g_counter]["value"]);
	$("#word").css("position","absolute");
	
	$("#word").css("text-align","center");
	$("#word").css("width","100px");
	$("#word").css("height","40px");
		$("#word").css("padding-top","10px");
	
	$("#word").css("background","#AAAAFF");
	$("#word").css("font-size","x-large");
	
	$("#word").css("cursor","pointer");
	
	$("#word").css("left",$(window).width()/2-50)
	$("#word").css("top",$(window).height()/2-40);
	
		/*TweenLite.to($("#word"), 2, {left:$(window).width()/2-50, 
					top:$(window).height()/2-40});*/
	
}
