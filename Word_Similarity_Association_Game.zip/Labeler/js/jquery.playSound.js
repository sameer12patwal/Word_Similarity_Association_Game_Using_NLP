(function($){

  $.extend({
    playSound: function(){
      return $("<embed src='"+arguments[0]+"' hidden='true' autostart='true' loop='false' class='playSound'>" + "<audio autoplay='autoplay' style='display:none;' controls='controls'><source src='"+arguments[0]+"' /><source src='"+arguments[0]+"' /></audio>").appendTo('body');
    }
  });

})(jQuery);