var g_classes;
var g_words;
var g_counter = -1;

var routeArray;
var k = -1;
var setVisualsInitialized = 0;


var sets = new Array();

//var req="http://cs.uef.fi/mopsi_dev/routes/server.php?param={%22request_type%22:%22get_reduced_routes_per_sets%22,%22routes%22:[{%22route_id%22:%221415361549849%22,%22user_id%22:%22260%22,%22set%22:%220%22},{%22route_id%22:%221415346522753%22,%22user_id%22:%22260%22,%22set%22:%221%22},{%22route_id%22:%221414934997812%22,%22user_id%22:%22260%22,%22set%22:%220%22},{%22route_id%22:%221414929842580%22,%22user_id%22:%22260%22,%22set%22:%221%22},{%22route_id%22:%221414917184425%22,%22user_id%22:%22260%22,%22set%22:%222%22},{%22route_id%22:%221414849687615%22,%22user_id%22:%22260%22,%22set%22:%220%22},{%22route_id%22:%221414594904951%22,%22user_id%22:%22260%22,%22set%22:%220%22},{%22route_id%22:%221414219929122%22,%22user_id%22:%22260%22,%22set%22:%223%22},{%22route_id%22:%221413868264961%22,%22user_id%22:%22260%22,%22set%22:%22undefined%22},{%22route_id%22:%221413777171826%22,%22user_id%22:%22260%22,%22set%22:%22undefined%22}]}"

var draggedElement = null;
var currentMousePos = {
  x: -1,
  y: -1
};
var routesLoaded = false;
var mapLoaded = false;

var map;
$(document).ready(function() {
  $("#routeTextArea").html(
    "60.170472,24.939998\n" + "60.170475,24.939804\n" + "60.170486,24.939710\n" + "60.170515,24.939635\n" + "60.170563,24.939557\n" + "60.170638,24.939495\n" + "60.170725,24.939473\n" + "60.170896,24.939456\n" + "60.170939,24.939443\n" + "60.170995,24.939383\n" + "60.171018,24.939233\n" + "60.171014,24.939083\n" + "60.171006,24.938971\n" + "60.170998,24.938873\n" + "60.170968,24.938421\n" + "60.170919,24.937764\n" + "60.170909,24.937616\n" + "60.170902,24.937485\n" + "60.170897,24.937331\n" + "60.170901,24.937194\n" + "60.171026,24.937009\n" + "60.171120,24.936824\n" + "60.171227,24.936567\n" + "60.171265,24.936303\n" + "60.171260,24.936168\n" + "60.171240,24.936062\n" + "60.171210,24.935942\n" + "60.171158,24.935751\n" + "60.171150,24.935611\n" + "60.171151,24.935485\n" + "60.171151,24.935330\n" + "60.171150,24.935072\n" + "60.171147,24.934558\n" + "60.171145,24.934260\n" + "60.171142,24.933111\n" + "60.171141,24.932916\n" + "60.171140,24.932730\n" + "60.171142,24.932443\n" + "60.171136,24.931886\n" + "60.171080,24.931753\n" + "60.171036,24.931633\n" + "60.170986,24.931472\n" + "60.170947,24.931326\n" + "60.170879,24.931083\n" + "60.170596,24.930258\n" + "60.170573,24.930184\n" + "60.170546,24.930094\n" + "60.170502,24.929951\n" + "60.170429,24.929714\n" + "60.170235,24.929083\n" + "60.170200,24.928970\n" + "60.170162,24.928849\n" + "60.170117,24.928709\n" + "60.169853,24.927862\n" + "60.169749,24.927524\n" + "60.169697,24.927359\n" + "60.169643,24.927189\n" + "60.169610,24.927051\n" + "60.169558,24.926815\n" + "60.169525,24.926702\n" + "60.169424,24.926377\n" + "60.169041,24.925157\n" + "60.168754,24.924249\n" + "60.168620,24.923821\n" + "60.168559,24.923652\n" + "60.168392,24.923221\n" + "60.168245,24.922901\n" + "60.167978,24.922078\n" + "60.167918,24.921900\n" + "60.167895,24.921751\n" + "60.167887,24.921580\n" + "60.167887,24.921365\n" + "60.167872,24.921018\n" + "60.167809,24.921030\n" + "60.167699,24.921044\n" + "60.167629,24.921055\n" + "60.167121,24.921114\n" + "60.167050,24.921114\n" + "60.166988,24.921102\n" + "60.166819,24.920991\n" + "60.166742,24.920954\n" + "60.166649,24.920936\n" + "60.166515,24.920938\n" + "60.165589,24.921090\n" + "60.165519,24.921093\n" + "60.165259,24.921119\n" + "60.165178,24.921131\n" + "60.165080,24.921132\n" + "60.165017,24.921113\n" + "60.164891,24.921044\n" + "60.164795,24.920988\n" + "60.164790,24.920868\n" + "60.164785,24.920776\n" + "60.164722,24.918947\n" + "60.164649,24.916694\n" + "60.164646,24.916555\n" + "60.164631,24.916116\n" + "60.164604,24.915579\n" + "60.164560,24.915255\n" + "60.164539,24.914585\n" + "60.164535,24.914486\n" + "60.164509,24.913663\n" + "60.164499,24.913332\n" + "60.164534,24.912909\n" + "60.164563,24.912707\n" + "60.164642,24.912514\n" + "60.165042,24.912087\n" + "60.165136,24.911979\n" + "60.165374,24.911672\n" + "60.165575,24.911354\n" + "60.165759,24.911035\n" + "60.165952,24.910643\n" + "60.166163,24.910123\n" + "60.166344,24.909591\n" + "60.166463,24.909150\n" + "60.166565,24.908691\n" + "60.166683,24.908113\n" + "60.166790,24.907526\n" + "60.166888,24.906918\n" + "60.166969,24.906324\n" + "60.167039,24.905636\n" + "60.167118,24.904559\n" + "60.167149,24.903864\n" + "60.167161,24.903189\n" + "60.167159,24.902586\n" + "60.167145,24.902065\n" + "60.167114,24.901328\n" + "60.167070,24.900614\n" + "60.167010,24.899896\n" + "60.166832,24.898161\n" + "60.165675,24.887867\n" + "60.165586,24.887025\n" + "60.165337,24.884751\n" + "60.165029,24.882157\n" + "60.164878,24.881034\n" + "60.164734,24.880070\n" + "60.164395,24.877969\n" + "60.164127,24.876521\n" + "60.163670,24.874230\n" + "60.163131,24.871630\n" + "60.162818,24.870036\n" + "60.162713,24.869420\n" + "60.162618,24.868784\n" + "60.162527,24.868062\n" + "60.162473,24.867487\n" + "60.162430,24.866787\n" + "60.162404,24.866110\n" + "60.162404,24.865465\n" + "60.162426,24.864653\n" + "60.162477,24.863812\n" + "60.162574,24.862889\n" + "60.162684,24.862036\n" + "60.162872,24.860877\n" + "60.163141,24.859323\n" + "60.163219,24.858869\n" + "60.163676,24.856230\n" + "60.164171,24.853404\n" + "60.164193,24.853271\n" + "60.164222,24.853100\n" + "60.164992,24.848701\n" + "60.165443,24.846100\n" + "60.165542,24.845417\n" + "60.165896,24.843523\n" + "60.166070,24.842637\n" + "60.166290,24.841534\n" + "60.166508,24.840570\n" + "60.166715,24.839744\n" + "60.166821,24.839404\n" + "60.167209,24.837965\n" + "60.167429,24.837142\n" + "60.167580,24.836541\n" + "60.167694,24.836045\n" + "60.167849,24.835497\n" + "60.168033,24.834628\n" + "60.168166,24.833982\n" + "60.168305,24.833244\n" + "60.168420,24.832589\n" + "60.168580,24.831625\n" + "60.168718,24.830786\n" + "60.168871,24.829645\n" + "60.169042,24.828299\n" + "60.169141,24.827501\n" + "60.169214,24.826904\n" + "60.169302,24.826247\n" + "60.169343,24.825982\n" + "60.169388,24.825761\n" + "60.169452,24.825541\n" + "60.169508,24.825377\n" + "60.169582,24.825196\n" + "60.169660,24.825057\n" + "60.169746,24.824935\n" + "60.169813,24.824844\n" + "60.169877,24.824772\n" + "60.169950,24.824707\n" + "60.170064,24.824636\n" + "60.170125,24.824604\n" + "60.170199,24.824584\n" + "60.170257,24.824578\n" + "60.170332,24.824579\n" + "60.170395,24.824599\n" + "60.170465,24.824626\n" + "60.170541,24.824685\n" + "60.170623,24.824777\n" + "60.170692,24.824842\n" + "60.170862,24.825019\n" + "60.171082,24.825346\n" + "60.171293,24.825609\n" + "60.171526,24.825856\n" + "60.171794,24.826125\n" + "60.171934,24.826254\n" + "60.172118,24.826384\n" + "60.172311,24.826493\n" + "60.172475,24.826575\n" + "60.172632,24.826652\n" + "60.173201,24.826929\n" + "60.173263,24.826956\n" + "60.173343,24.826992\n" + "60.173543,24.827085\n" + "60.173976,24.827313\n" + "60.175450,24.828063\n" + "60.175768,24.828231\n" + "60.176067,24.828426\n" + "60.176339,24.828636\n" + "60.176539,24.828805\n" + "60.176694,24.828959\n" + "60.176794,24.829093\n" + "60.176973,24.829296\n" + "60.177094,24.829415\n" + "60.177319,24.829677\n" + "60.177561,24.830007\n" + "60.178021,24.830735\n" + "60.178402,24.831452\n" + "60.178691,24.832113\n" + "60.178926,24.832706\n" + "60.179090,24.833183\n" + "60.179235,24.833635\n" + "60.179384,24.834149\n" + "60.179496,24.834592\n" + "60.179538,24.834755\n" + "60.179575,24.834910\n" + "60.179636,24.835191\n" + "60.179758,24.835886\n" + "60.179886,24.836570\n" + "60.179943,24.836815\n" + "60.180032,24.837309\n" + "60.180108,24.837541\n" + "60.180259,24.838743\n" + "60.180414,24.840018\n" + "60.180611,24.841605\n" + "60.180771,24.842912\n" + "60.180977,24.844571\n" + "60.181194,24.846306\n" + "60.181523,24.849017\n" + "60.181542,24.849434\n" + "60.181620,24.850089\n" + "60.181655,24.850427\n" + "60.181704,24.850809\n" + "60.181753,24.851233\n" + "60.181861,24.851725\n" + "60.181910,24.852081\n" + "60.181962,24.852428\n" + "60.182036,24.852878\n" + "60.182139,24.853311\n" + "60.182368,24.854041\n" + "60.182559,24.854480\n" + "60.182646,24.854655\n" + "60.182750,24.854864\n" + "60.182847,24.855019\n" + "60.182988,24.855216\n" + "60.183123,24.855390\n" + "60.183593,24.855887\n" + "60.183810,24.856152\n" + "60.184002,24.856422\n" + "60.184155,24.856667\n" + "60.184305,24.856950\n" + "60.184425,24.857212\n" + "60.184536,24.857476\n" + "60.184651,24.857835\n" + "60.184768,24.858261\n" + "60.184804,24.858512\n" + "60.184847,24.858724\n" + "60.184917,24.859343\n" + "60.184974,24.859974\n" + "60.185032,24.860526\n" + "60.185216,24.861733\n" + "60.185379,24.862427\n" + "60.185493,24.862802\n" + "60.185666,24.863287\n" + "60.185864,24.863777\n" + "60.186475,24.865397\n" + "60.186720,24.866535\n" + "60.186753,24.866740\n" + "60.186787,24.866970\n" + "60.186890,24.867709\n" + "60.187077,24.868987\n" + "60.187115,24.869264\n" + "60.187473,24.871519\n" + "60.187559,24.872089\n" + "60.187732,24.873157\n" + "60.187800,24.873555\n" + "60.187872,24.873891\n" + "60.187917,24.874069\n" + "60.188014,24.874440\n" + "60.188063,24.874615\n" + "60.188089,24.874698\n" + "60.188128,24.874813\n" + "60.188203,24.874961\n" + "60.188489,24.875475\n" + "60.188828,24.876011\n" + "60.189102,24.876375\n" + "60.189314,24.876582\n" + "60.189623,24.876819\n" + "60.189917,24.876965\n" + "60.190179,24.877086\n" + "60.190572,24.877256\n" + "60.190970,24.877432\n" + "60.191078,24.877480\n" + "60.191386,24.877598\n" + "60.191693,24.877733\n" + "60.191829,24.877806\n" + "60.192024,24.877962\n" + "60.192169,24.878156\n" + "60.192353,24.878497\n" + "60.192425,24.878701\n" + "60.192472,24.878923\n" + "60.192499,24.879085\n" + "60.192505,24.879211\n" + "60.192508,24.879386\n" + "60.192508,24.879552\n" + "60.192500,24.879690\n" + "60.192430,24.880345\n" + "60.192399,24.880616\n" + "60.192356,24.881032\n" + "60.192342,24.881245\n" + "60.192346,24.881454\n" + "60.192373,24.881627\n" + "60.192401,24.881759\n" + "60.192450,24.881887\n" + "60.192637,24.882223\n" + "60.192715,24.882355\n" + "60.192766,24.882441\n" + "60.192860,24.882599\n" + "60.192971,24.882754\n" + "60.193078,24.882899\n" + "60.193440,24.883274\n" + "60.193798,24.883676\n" + "60.194189,24.884136\n" + "60.194261,24.884216\n" + "60.194319,24.884279\n" + "60.194374,24.884162\n" + "60.194428,24.884077\n" + "60.194676,24.883687\n" + "60.194805,24.883484\n" + "60.195456,24.882470\n" + "60.195522,24.882352\n" + "60.195768,24.881956\n" + "60.195944,24.881691\n" + "60.196058,24.881519\n" + "60.196138,24.881385\n" + "60.196173,24.881246\n" + "60.196254,24.880739\n" + "60.196273,24.880631\n" + "60.196932,24.881172\n" + "60.197005,24.881233\n" + "60.196916,24.881678\n" + "60.196592,24.883279\n" + "60.196582,24.883490\n" + "60.196593,24.883635\n" + "60.196497,24.884088\n" + "60.196451,24.884303\n" + "60.196400,24.884552\n" + "60.196363,24.884718\n" + "60.196315,24.884921\n" + "60.196181,24.885655\n" + "60.195960,24.886754\n" + "60.195777,24.887669\n" + "60.195724,24.887939\n" + "60.195508,24.888954\n" + "60.195383,24.889449\n" + "60.195262,24.889833\n" + "60.195130,24.890189\n" + "60.194741,24.891016\n" + "60.194651,24.891205\n" + "60.194600,24.891311\n" + "60.194561,24.891392\n" + "60.194085,24.892440\n" + "60.193724,24.893250\n" + "60.193554,24.893643\n" + "60.193174,24.894607\n" + "60.193132,24.894720\n" + "60.193089,24.894820\n" + "60.193011,24.895040\n" + "60.192595,24.896193\n" + "60.192450,24.896661\n" + "60.191998,24.897920\n" + "60.191785,24.898512\n" + "60.191467,24.899365\n" + "60.191420,24.899590\n" + "60.191378,24.899814\n" + "60.191348,24.900035\n" + "60.191333,24.900186\n" + "60.191324,24.900347\n" + "60.191316,24.900528\n" + "60.191304,24.901119\n" + "60.191293,24.901661\n" + "60.191290,24.901811\n" + "60.191282,24.902211\n" + "60.191264,24.903082\n" + "60.191235,24.904469\n" + "60.191224,24.904733\n" + "60.191200,24.905115\n" + "60.191184,24.905858\n" + "60.191168,24.906360\n" + "60.191173,24.906611\n" + "60.191163,24.907081\n" + "60.191162,24.907257\n" + "60.191160,24.907551\n" + "60.191122,24.909941\n" + "60.191119,24.910070\n" + "60.191092,24.910555\n" + "60.191081,24.910826\n" + "60.191063,24.911724\n" + "60.191064,24.911957\n" + "60.191071,24.912624\n" + "60.191071,24.912747\n" + "60.191054,24.913038\n" + "60.191027,24.913237\n" + "60.190788,24.913778\n" + "60.190498,24.914424\n" + "60.190427,24.914587\n" + "60.190383,24.914688\n" + "60.190266,24.914969\n" + "60.189793,24.916045\n" + "60.189724,24.916188\n" + "60.189665,24.916304\n" + "60.189568,24.916462\n" + "60.189339,24.916844\n" + "60.189052,24.917278\n" + "60.188908,24.917467\n" + "60.188820,24.917575\n" + "60.188201,24.918243\n" + "60.188020,24.918434\n" + "60.187926,24.918516\n" + "60.187842,24.918599\n" + "60.187118,24.919335\n" + "60.186975,24.919524\n" + "60.186909,24.919617\n" + "60.186440,24.920233\n" + "60.186145,24.920616\n" + "60.185823,24.921043\n" + "60.185576,24.921372\n" + "60.185330,24.921688\n" + "60.185248,24.921794\n" + "60.185179,24.921904\n" + "60.184710,24.922611\n" + "60.184047,24.923642\n" + "60.183965,24.923770\n" + "60.183869,24.923936\n" + "60.183805,24.924060\n" + "60.183744,24.924154\n" + "60.183358,24.924750\n" + "60.183304,24.924833\n" + "60.183175,24.925031\n" + "60.182394,24.926219\n" + "60.182336,24.926306\n" + "60.181919,24.926925\n" + "60.181858,24.927013\n" + "60.181744,24.927160\n" + "60.181638,24.927260\n" + "60.181540,24.927331\n" + "60.181263,24.927495\n" + "60.180582,24.927898\n" + "60.180513,24.927939\n" + "60.180430,24.927988\n" + "60.179760,24.928339\n" + "60.179012,24.928724\n" + "60.178672,24.928875\n" + "60.178592,24.928907\n" + "60.178509,24.928943\n" + "60.177979,24.929208\n" + "60.177845,24.929289\n" + "60.177548,24.929465\n" + "60.177498,24.929500\n" + "60.177429,24.929552\n" + "60.177314,24.929666\n" + "60.177197,24.929789\n" + "60.177039,24.929974\n" + "60.176388,24.930771\n" + "60.176335,24.930841\n" + "60.176269,24.930919\n" + "60.176212,24.930989\n" + "60.175960,24.931286\n" + "60.175700,24.931575\n" + "60.175476,24.931815\n" + "60.175260,24.932024\n" + "60.175193,24.932091\n" + "60.174744,24.932553\n" + "60.174682,24.932611\n" + "60.174602,24.932715\n" + "60.174336,24.932963\n" + "60.174226,24.933067\n" + "60.174045,24.933231\n" + "60.173801,24.933467\n" + "60.173730,24.933532\n" + "60.173544,24.933678\n" + "60.173280,24.933920\n" + "60.172552,24.934634\n" + "60.172485,24.934702\n" + "60.172372,24.934812\n" + "60.172319,24.934864\n" + "60.172170,24.935011\n" + "60.171381,24.935764\n" + "60.171337,24.935811\n" + "60.171210,24.935942\n" + "60.171148,24.936022\n" + "60.171082,24.936138\n" + "60.171023,24.936273\n" + "60.170974,24.936402\n" + "60.170885,24.936630\n" + "60.170815,24.936908\n" + "60.170806,24.937026\n" + "60.170816,24.937197\n" + "60.170824,24.937298\n" + "60.170850,24.937631\n" + "60.170900,24.938442\n" + "60.170925,24.938858\n" + "60.170935,24.938988\n" + "60.170942,24.939127\n" + "60.170922,24.939252\n" + "60.170857,24.939300\n" + "60.170627,24.939340\n" + "60.170548,24.939362\n" + "60.170496,24.939391\n" + "60.170449,24.939448\n" + "60.170360,24.939587\n" + "60.170301,24.939743\n" + "60.170273,24.939918\n" + "60.170282,24.940228\n" + "60.170286,24.940412\n" + "60.170309,24.941382\n" + "60.170314,24.941532\n" + "60.170331,24.942365\n" + "60.170336,24.942545\n" + "60.170344,24.942755\n" + "60.170202,24.942758\n" + "60.170060,24.942856\n" + "60.169830,24.942891\n" + "60.169505,24.943108\n" + "60.169830,24.942891\n" + "60.170060,24.942856\n" + "60.170243,24.942751\n" + "60.170344,24.942755\n" + "60.170526,24.942756\n" + "60.170523,24.942538\n" + "60.170519,24.942392\n" + "60.170512,24.942212"
  );




  google.maps.event.addDomListener(window, 'load', initializeMap);


  //var result=jQuery.parseJSON(pageParams);
  /*var routes=pageParams.routes;
  routeArray=new Array();
 
  emptySets();
  for(var i=0;i<routes.length;i++){
   
   routeArray[routes[i]["user_id"]+"_"+routes[i]["route_id"]]={overlap:-1, offset:i, reducedPath:routes[i]["reducedPath"]};
   //routeArray[routes[i]["user_id"]+"_"+routes[i]["route_id"]]["reducedPath"]=routes[i]["reducedPath"];
   var setIndex=(Number)(routes[i]["set"]);
   if(isNaN(setIndex)){
    setIndex=0;
   }
   k=Math.max(k,setIndex+1);
   //k=10;
   if(sets[routes[i]["set"]]==null){
    sets[routes[i]["set"]]=new Array();
    sets[routes[i]["set"]]["routes"]=new Array();
   }
   sets[routes[i]["set"]]["routes"].push(routes[i]["user_id"]+"_"+routes[i]["route_id"]);
  }
  for(var i in routeArray){
   routeArray[i]["offset"]=Math.PI/2+3*Math.PI/2*routeArray[i]["offset"]/routes.length;;
  }
  routesLoaded=true;
  if(mapLoaded==true){
   drawRoutesToMap();
  }
 
  google.maps.event.addDomListener(window, 'load', initializeMap);

  $(document).mousemove(function(event) {
         currentMousePos.x = event.pageX;
         currentMousePos.y = event.pageY;
     });

 
 
  //fillSets();
  drawSets();*/



});
var polyline = null;
var redPolyline = null;
var level=5;
var reductionResults=null;
function setLevel(nr){
  $("#lv"+1).css("font-weight","normal");
  $("#lv"+2).css("font-weight","normal");
  $("#lv"+3).css("font-weight","normal");
  $("#lv"+4).css("font-weight","normal");
  $("#lv"+5).css("font-weight","normal");
  $("#lv"+1).css("background-color","#fff");
  $("#lv"+2).css("background-color","#fff");
  $("#lv"+3).css("background-color","#fff");
  $("#lv"+4).css("background-color","#fff");
  $("#lv"+5).css("background-color","#fff");
  $("#lv"+nr).css("font-weight","bold");
  $("#lv"+nr).css("background-color","#00CCFF");
  var polylineArray = new Array();
  var bounds = new google.maps.LatLngBounds();
  var l1 = reductionResults["level_"+nr];
  l1 = l1.split(",");
  
  $("#outPts").html(l1.length/2);

  var csv = "";
  for (var i = 0; i < l1.length; i+=2) {
    var point = new google.maps.LatLng(l1[i], l1[i+1]);
    polylineArray.push(point);
    bounds.extend(point);
    csv = l1[i] + "," + l1[i+1] + "\n" + csv;
  }

  $("#reducedTextArea").html(csv);

  if (redPolyline != null) {
    redPolyline.setMap(null);
  }
  redPolyline = new google.maps.Polyline({
    path: polylineArray,
    strokeColor: '#ff0000',
    strokeWeight: 2
  });
  redPolyline.setMap(map);
  //map.fitBounds(bounds);
}
function drawData(data) {
  var polylineArray = new Array();
  var bounds = new google.maps.LatLngBounds();
  var csv = "";
  
  
  $("#inPts").html(data.length);
  for (var i = 0; i < data.length; i++) {
    var point = new google.maps.LatLng(data[i][0], data[i][1]);
    polylineArray.push(point);
    bounds.extend(point);
    if (i > 0) {
      csv += ",";
    }
    csv += data[i][0] + "," + data[i][1];
  }

  if (polyline != null) {
    polyline.setMap(null);
  }
  polyline = new google.maps.Polyline({
    path: polylineArray,
    strokeColor: '#000000',
    strokeWeight: 5
  });
  polyline.setMap(map);
  map.fitBounds(bounds);
  
  
  $.post("http://cs.uef.fi/mopsi_dev/routes/server.php", {
    param: '{"request_type": "reduce_route", "csv": "' + csv + '" }'
  }, function(data) {
    reductionResults = jQuery.parseJSON(data);
    setLevel(level);
  });
}

function fillSets() {
  emptySets();
  var cnt = 0;
  for (var i in routeArray) {
    sets[cnt % k].push(i);
    cnt++;
  }
}

function drawSets() {
  for (var i = 0; i < sets.length; i++) {
    var set = sets[i];

    set["X"] = $(window).width() / 2 + (Math.cos(Math.PI + Math.PI * 2 * i / sets.length)) * ($(window).width() / 2 - 200);
    set["Y"] = $(window).height() / 2 + (Math.sin(Math.PI + Math.PI * 2 * i / sets.length)) * ($(window).height() / 2 - 120);
    set["index"] = i;
    if (setVisualsInitialized < k) {
      var newDiv = document.createElement("div");
      $(newDiv).attr("id", "s_" + i);
      $(newDiv).addClass("largeCircle");
      $(newDiv).mouseover(showSet);
      $("#container").append(newDiv);


      var newDiv2 = document.createElement("div");
      $(newDiv2).attr("id", "t_" + i);
      $(newDiv2).addClass("overlapText");
      $(newDiv2).css("left", set["X"]);
      $(newDiv2).css("top", set["Y"]);
      $("#container").append(newDiv2);
      //
      $(newDiv).css("left", set["X"]);
      $(newDiv).css("top", set["Y"]);
    }


    queryNovelty(set);


  }

  if (setVisualsInitialized < k) {
    var newDiv2 = document.createElement("div");
    $(newDiv2).attr("id", "meanOverlap");
    $(newDiv2).css("position", "overlap");
    $(newDiv2).css("background", "white");
    $(newDiv2).addClass("overlapText");

    $(newDiv2).css("left", "70px");
    $(newDiv2).css("top", "0px");
    /*$(newDiv2).css("left",set["X"]);
    $(newDiv2).css("top",set["Y"]);*/
    $("#container").append(newDiv2);
  }
}

function onDragEndFunction(e) {
  removeFromRespectiveSet(this.id);


  for (var k = 0; k < sets.length; k++) {
    if (Draggable.get($("#" + this.id)).hitTest($("#s_" + k))) {
      sets[k]["routes"].push(this.id);
      break;
    }
  }

  var transform = $("#" + this.id).css("transform");
  $("#" + this.id).remove();
  var newDiv = document.createElement("div");
  $(newDiv).attr("id", this.id);
  $(newDiv).addClass("circle");
  $(newDiv).mouseover(showRoute);
  $(newDiv).css("left", currentMousePos.x);
  $(newDiv).css("top", currentMousePos.y);
  $("#container").append(newDiv);

  Draggable.create($("#" + this.id), {
    type: "x,y",
    edgeResistance: 0.65,
    bounds: "#container"
  });
  Draggable.get($("#" + this.id)).addEventListener("dragend", onDragEndFunction);


  drawSets();

}

function removeFromRespectiveSet(id) {
  for (var i = 0; i < sets.length; i++) {
    for (var j = 0; j < sets[i]["routes"].length; j++) {
      if (sets[i]["routes"][j] == id) {
        sets[i]["routes"].splice(j, 1);
        return;
      }
    }
  }
}

function emptySets() {
  sets = new Array();
  for (var i = 0; i < k; i++) {
    sets[i] = new Array();
  }
}

function makeBackground(sample) {
    var background = new Array();
    for (var i = 0; i < sample.length; i++) {
      for (var j = 0; j < sample[i].length; j++) {
        background[sample[i][j].hashCode] = true;
      }
    }
    return background;
  }
  /*
  rt.js:30 260_1414917184425
  rt.js:30 260_1414929842580
  rt.js:30 260_1414934997812
  rt.js:30 260_1415346522753
  rt.js:30 260_1415361549849
  rt.js:30 260_1415548754315
  */
function novelty(route, background) {
  var novelty = route.length;
  for (var i = 0; i < route.length; i++) {
    if (background[route[i].hashCode] == true) {
      novelty--;
    }
  }
  return novelty / route.length;
}

function queryNovelty(set) {
  var routes = new Array();
  for (var i = 0; i < set["routes"].length; i++) {
    var element = set["routes"][i].split("_");
    routes.push({
      "user_id": element[0],
      "route_id": element[1]
    });
  }
  console.log('http://cs.uef.fi/mopsi_dev/routes/server.php?param={"request_type":"get_novelties","routes":' + JSON.stringify(routes) + '}');
  $.get('http://cs.uef.fi/mopsi_dev/routes/server.php?param={"request_type":"get_novelties","routes":' + JSON.stringify(routes) + '}', function(data) {

    var novelties = jQuery.parseJSON(data);
    novelties = jQuery.parseJSON(novelties);

    var totalOverlap = 0;
    for (var j = 0; j < set["routes"].length; j++) {
      /*var sample=new Array();
      for(var k=0;k<set.length;k++){
       if(k!=j){
        sample.push(routeArray[set[k]]["cells"]);
       }
      }*/
      //var background=makeBackground(sample);
      routeArray[set["routes"][j]]["overlap"] = 1 - novelties[set["routes"][j]];

      totalOverlap += routeArray[set["routes"][j]]["overlap"];
      if (setVisualsInitialized < k) {
        var newDiv = document.createElement("div");
        $(newDiv).attr("id", "" + set["routes"][j]);
        $(newDiv).addClass("circle");

        $(newDiv).mouseover(showRoute);
        $("#container").append(newDiv);
        //
        Draggable.create($("#" + set["routes"][j]), {
          type: "x,y",
          edgeResistance: 0.65,
          bounds: "#container"
        });


        Draggable.get($("#" + set["routes"][j])).addEventListener("dragend", onDragEndFunction);
      }

      TweenLite.to($("#" + set["routes"][j]), 2, {
        left: set ["X"] + Math.cos(routeArray[set["routes"][j]]["offset"]) * routeArray[set["routes"][j]]["overlap"] * 100,
        top: set ["Y"] + Math.sin(routeArray[set["routes"][j]]["offset"]) * routeArray[set["routes"][j]]["overlap"] * 100
      });

    }
    if (set["routes"].length == 0) {
      $("#" + "t_" + set["index"]).html('');
    } else {
      totalOverlap /= set["routes"].length;
      $("#" + "t_" + set["index"]).html(totalOverlap.toFixed(1));
    }
    updateAverageOverlap();
    setVisualsInitialized++;
  });

}


function updateAverageOverlap() {
  var averageOverlap = 0;
  for (var i = 0; i < sets.length; i++) {
    var val = $("#t_" + i).html();
    if (!isNaN(val)) {
      averageOverlap += (Number)(val);
    }
  }
  if (sets.length != 0) {
    averageOverlap /= sets.length;
  }
  $("#meanOverlap").html(averageOverlap.toFixed(2));
}

function initialize(classes) {

  for (var i = 0; i < classes.length; i++) {
    var newDiv = document.createElement("div");
    $(newDiv).html(classes[i]["value"]);
    $(newDiv).css("position", "absolute");

    $(newDiv).css("text-align", "center");
    $(newDiv).css("border", "dashed 3px");
    $(newDiv).css("padding-top", "20px");
    $(newDiv).css("width", "100px");
    $(newDiv).css("height", "50px");

    $(newDiv).css("background", "#DDDDDD");
    $(newDiv).css("font-size", "x-large");

    $(newDiv).attr("id", "class_" + classes[i]["id"]);
    var radius = 100;

    var w = Math.max($(window).width() / 2, 260);
    var h = Math.max($(window).height() / 2, 220);
    $(newDiv).css("left", $(window).width() / 2 + (Math.cos(Math.PI + Math.PI * 2 * i / classes.length)) * (w - 100) - 50);
    $(newDiv).css("top", $(window).height() / 2 + (Math.sin(Math.PI + Math.PI * 2 * i / classes.length)) * (h - 100) - 50);
    $("#container").append(newDiv);
  }

  var newDiv = document.createElement("div");
  $(newDiv).attr("id", "word");
  $("#container").append(newDiv);
  showNextWord();

  Draggable.create($("#word"), {
    type: "x,y",
    edgeResistance: 0.65,
    bounds: "#container",
    throwProps: true,
    onDragEnd: function(e) {
      if (g_counter < g_words.length) {
        for (var i = 0; i < classes.length; i++) {
          if (this.hitTest("#class_" + classes[i]["id"])) {
            g_words[g_counter]["classId"] = classes[i]["id"];
            if (classes[i]["id"] == g_words[g_counter]["correctClassId"] || g_words[g_counter]["correctClassId"] == -1) {
              console.log("CORRECT");

              showNextWord();
            } else {
              console.log("INCORRECT");

              showNextWord();
            }
          }
        }
      } else {}
    }

  });
}


function showNextWord() {
  g_counter++;
  if (g_counter >= g_words.length) {
    for (var i = 0; i < g_words.length; i++) {
      g_words[i]["wordId"] = g_words[i]["id"];
    }
    $.get('http://cs.uef.fi/paikka/Radu/labeler/serverside/server.php?param={"request_type":"submit_results","name":"radu","results":' + JSON.stringify(g_words) + '}');



    alert("done");
    Draggable.get($("#word")).kill();


    return;
  }
  $("#word").html(g_words[g_counter]["value"]);
  $("#word").css("position", "absolute");

  $("#word").css("text-align", "center");
  $("#word").css("width", "100px");
  $("#word").css("height", "40px");
  $("#word").css("padding-top", "10px");

  $("#word").css("background", "#AAAAFF");
  $("#word").css("font-size", "x-large");

  $("#word").css("cursor", "pointer");

  $("#word").css("left", $(window).width() / 2 - 50)
  $("#word").css("top", $(window).height() / 2 - 40);


}


function initializeMap() {
  var mapOptions = {
    zoom: 3,
    center: new google.maps.LatLng(0, -180),
    mapTypeId: google.maps.MapTypeId.TERRAIN
  };

  map = new google.maps.Map(document.getElementById('map-canvas'),
    mapOptions);


  //var mapWidth=$(window).width()-700;
  //var mapHeight=$(window).height()-500;
  var mapWidth = $(window).width();
  var mapHeight = $(window).height();
  $("#map-canvas").css("width", mapWidth);
  $("#map-canvas").css("height", mapHeight);
  $("#map-canvas").css("margin-left", (-mapWidth / 2));
  $("#map-canvas").css("margin-top", (-mapHeight / 2));



  /*mapLoaded=true;
  if(routesLoaded==true){
    drawRoutesToMap();
  }*/

  computeReduction();
  
  $("#lv1").click(function(){setLevel(1);});
  $("#lv2").click(function(){setLevel(2);});
  $("#lv3").click(function(){setLevel(3);});
  $("#lv4").click(function(){setLevel(4);});
  $("#lv5").click(function(){setLevel(5);});
  $("#recalc").click(function(){computeReduction();});

}

function computeReduction(){
  var s = $("#routeTextArea").val();

  var data = Papa.parse(s);

  if (data["errors"].length == 0) {
    if (data["data"].length > 1) {
      var i = 0;
      for (i = 0; i < data["data"].length; i++) {
        if (Number(data["data"][i][0]) != data["data"][i][0] || Number(data["data"][i][1]) != data["data"][i][1]) {
          break;
        }
      }
      if (i != data["data"].length) {
        alert("Number format problem");
      } else {
        drawData(data["data"]);
      }
    } else {
      alert("Route too short");
    }
  } else {
    alert("Error in the CSV");
  }
}

function drawRoutesToMap() {
  for (var i in routeArray) {
    var reducedPath = routeArray[i]["reducedPath"];
    var polylineArray = new Array();

    var bounds = new google.maps.LatLngBounds();
    for (var j = 0; j < reducedPath.length; j++) {
      var point = new google.maps.LatLng(reducedPath[j][0], reducedPath[j][1]);
      polylineArray.push(point);
      bounds.extend(point);
    }

    var polyline = new google.maps.Polyline({
      path: polylineArray,
      strokeColor: '#000000',
      strokeWeight: 5
    });

    routeArray[i]["polyline"] = polyline;
    routeArray[i]["bounds"] = bounds;
  }
}

function hideAllRoutes() {
  for (var i in routeArray) {
    if (routeArray[i]["polyline"] != null) {
      routeArray[i]["polyline"].setMap(null);
      routeArray[i]["polyline"].setOptions({
        strokeColor: "#000000"
      });
    }
  }
}

function showSet() {
  var id = this.id;
  id = id.split("_");
  id = id[1];

  hideAllRoutes();

  var set = sets[id]["routes"];


  var bounds = null;
  for (var i = 0; i < set.length; i++) {
    if (routeArray[set[i]]["polyline"] != null) {
      routeArray[set[i]]["polyline"].setMap(map);

      if (bounds == null) {
        bounds = new google.maps.LatLngBounds(
          routeArray[set[i]]["bounds"].getSouthWest(),
          routeArray[set[i]]["bounds"].getNorthEast());
      } else {
        bounds.union(routeArray[set[i]]["bounds"]);
      }
    }
  }

  if (bounds != null) {
    map.fitBounds(bounds);
  }
}

var nextZIndex = 1000;

function showRoute() {
  var id = this.id;

  //hideAllRoutes();


  if (routeArray[id]["polyline"] != null) {
    routeArray[id]["polyline"].setMap(map);
    routeArray[id]["polyline"].setOptions({
      strokeColor: "#FF0000",
      zIndex: nextZIndex
    });
    nextZIndex++;
    //map.fitBounds(routeArray[id]["bounds"]); 
  }


}