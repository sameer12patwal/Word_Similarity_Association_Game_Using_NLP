<?php

?>
<html>

<head>
    <title>Reduction API</title>
	<script>
		//var pageParams=<?php echo($_POST["param"]);?>;
	</script>
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script src="js/red.js"></script>
    <script src="js/plugins/CSSPlugin.js"></script>
    <script src="js/utils/Draggable.js"></script>
    <script src="js/TweenLite.js"></script>
    <script src="js/TweenMax.js"></script>
    <script src="js/papaparse.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp"></script>
    <link rel="stylesheet" type="text/css" href="css/rt.css"></link>
</head>

<body style="overflow:hidden;width:100%;height:100%;">
	<div id="container" style="width:100%;height:100%;">
		<div style="height: 95%;position: absolute;width: 185px;z-index: 1;left: 100;background-color:#fff; margin-top: 10px;">
			Route Input&nbsp;(<span id="inPts"></span> pts)<br>
			<textarea id="routeTextArea" style="height: 100%;position: absolute;width: 185px;z-index: 1;"></textarea>
		</div>
		<div style="height: 93px;position: absolute;width: 330px;z-index: 1;left: 285;background-color:#fff; margin-top: 10px;word-wrap: break-word;text-align: justify;margin-left:5px;">
			You can substitute the sample route points on the left and <button id="recalc" >Recalculate</button> different levels of reduction.<br><br>
			Alternatively, you can call our API using GET or POST. Here is a sample <a href='http://cs.uef.fi/mopsi_dev/routes/server.php?param={"request_type":"reduce_route","csv":"60.170472,24.939998,60.170475,24.939804,60.170486,24.939710,60.170515,24.939635,60.170563,24.939557,60.170638,24.939495,60.170725,24.939473,60.170896,24.939456,60.170939,24.939443,60.170995,24.939383,60.171018,24.939233,60.171014,24.939083,60.171006,24.938971,60.170998,24.938873,60.170968,24.938421,60.170919,24.937764,60.170909,24.937616,60.170902,24.937485,60.170897,24.937331,60.170901,24.937194,60.171026,24.937009,60.171120,24.936824,60.171227,24.936567,60.171265,24.936303,60.171260,24.936168,60.171240,24.936062,60.171210,24.935942,60.171158,24.935751,60.171150,24.935611,60.171151,24.935485,60.171151,24.935330,60.171150,24.935072,60.171147,24.934558,60.171145,24.934260,60.171142,24.933111,60.171141,24.932916,60.171140,24.932730,60.171142,24.932443,60.171136,24.931886,60.171080,24.931753,60.171036,24.931633,60.170986,24.931472,60.170947,24.931326,60.170879,24.931083,60.170596,24.930258,60.170573,24.930184,60.170546,24.930094,60.170502,24.929951,60.170429,24.929714,60.170235,24.929083,60.170200,24.928970,60.170162,24.928849,60.170117,24.928709,60.169853,24.927862,60.169749,24.927524,60.169697,24.927359,60.169643,24.927189,60.169610,24.927051,60.169558,24.926815,60.169525,24.926702,60.169424,24.926377,60.169041,24.925157,60.168754,24.924249,60.168620,24.923821,60.168559,24.923652,60.168392,24.923221,60.168245,24.922901,60.167978,24.922078,60.167918,24.921900,60.167895,24.921751,60.167887,24.921580,60.167887,24.921365,60.167872,24.921018,60.167809,24.921030,60.167699,24.921044,60.167629,24.921055,60.167121,24.921114,60.167050,24.921114,60.166988,24.921102,60.166819,24.920991,60.166742,24.920954"}' target="_blank">request</a>.
			
			
		</div>
		<div style="height: 95%;position: absolute;width: 185px;z-index: 1;right: 100;background-color:#fff; margin-top: 10px;">
			Level <span id="lv1" style="cursor:pointer;">1</span>&nbsp;
			<span id="lv2" style="cursor:pointer;">2</span>&nbsp;
			<span id="lv3" style="cursor:pointer;">3</span>&nbsp;
			<span id="lv4" style="cursor:pointer;">4</span>&nbsp;
			<span id="lv5" style="cursor:pointer;">5</span>&nbsp;(<span id="outPts"></span> pts)<br>
			<textarea id="reducedTextArea" style="height: 100%;position: absolute;width: 185px;z-index: 1;"></textarea>
		</div>
		<div id="map-canvas"></div>
	</div>
</body>

</html>
