<?php

?>
<html>

<head>
    <title>Overlap</title>
	<script>
		var pageParams=<?php echo($_POST["param"]);?>;
	</script>
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script src="js/rt.js"></script>
    <script src="js/plugins/CSSPlugin.js"></script>
    <script src="js/utils/Draggable.js"></script>
    <script src="js/TweenLite.js"></script>
    <script src="js/TweenMax.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp"></script>
    <link rel="stylesheet" type="text/css" href="css/rt.css"></link>
</head>

<body style="overflow:hidden;width:100%;height:100%;">
	<div id="container" style="width:100%;height:100%;">
		<div id="map-canvas"></div>
	</div>
</body>

</html>
