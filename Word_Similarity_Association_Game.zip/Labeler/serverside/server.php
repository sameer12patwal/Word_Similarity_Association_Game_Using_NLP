<?php

error_reporting(0);
mb_internal_encoding("UTF-8");
require_once("labelerHandler.class.php");
$paramJson = $_POST['param'];
if ($paramJson == "") 
{
    $paramJson = $_GET['param'];
}

$server = new LabelerRequestParser();
$server->processJsonRequest($paramJson);

class LabelerRequestParser
{
    public function processJsonRequest($paramJson, $silent = false)
    {
        $param = json_decode($paramJson, true); // parse the parameters
		
        return $this->processRequest($param, $silent);
    }
    
    public function processRequest($param, $silent = false)
    {
        $handle = new LabelerHandler();
        $type   = $param['request_type'];
        switch ($type) {
            case 'make_game':
                $response = $handle->makeGame($param);
                break;
            case 'submit_results': //ok
                $response = $handle->submitResults($param);
                break;
           
            case 'get_words': //ok
                $response = $handle->getWords($param);
                break;
            case 'get_classes': //ok
                $response = $handle->getClasses($param);
                break;
            case 'get_results': //ok
                $response = $handle->getResults($param);
                break;
		   
            case 'reset_word': //  TEST
                $response = $handle->resetWord($param);
                break;
            case 'remove_class': //ok
                $response = $handle->removeClass($param);
                break;
            case 'add_class': //ok
                $response = $handle->addClass($param);
                break;
            case 'remove_word': //ok
                $response = $handle->removeWord($param);
                break;
            case 'add_word': //ok
                $response = $handle->addWord($param);
                break;
            default:
                $response = array(
                    'message' => 'Unknown operation!'
                );
                break;
        }
        echo json_encode($response);
    }
}

?>