<?php


mb_internal_encoding("UTF-8");
require_once("database.class.php");
error_reporting(0);
session_start();


class LabelerHandler
{
    
    private $lnk = null;
    private $session = null;
    private $database = null;
    
    public function __construct()
    {
        $this->database = new database();
        $this->lnk      = $this->getDbLnk($this->database);
        $this->session  = mt_rand();
    }
    //
    public function getDbLnk($database)
    {
        $lnk = $database->connectToDb();
        mysqli_set_charset($lnk, "utf8");
        return $lnk;
    }
    
	//
	// INSERTS
	//
	// adds a new word into the system
    function addWord($params)
    {
        $word  = $params["word"];
		
		$query = "INSERT INTO Labeler_Words (Value) VALUES ('$word');";

        if (mysqli_query($this->lnk, $query)) {
            $success   = true;
        } else {
            $success = false;
        }
        return array(
            "success" => $success
        );
    }
	
	// adds a new class into the system
    function addClass($params)
    {
        $class  = $params["class"];
		
		$query = "INSERT INTO Labeler_Classes (Value) VALUES ('$class');";
		
        if (mysqli_query($this->lnk, $query)) {
            $success   = true;
        } else {
            $success = false;
        }		
        return array(
            "success" => $success
        );
    }
	
	// stores results
    function submitResults($params)
    {
        $results  = $params["results"];
		$name=$params["name"];
		$correct=0;
		$wrong=0;
		$unlabeled=0;
		$labeled=0;
		$query = "INSERT INTO Labeler_Observations (WordId, ClassId) VALUES ";
		
		$labelingDone=false;
		for($i=0;$i<count($results);$i++){
			if($results[$i]["classId"]==$results[$i]["correctClassId"] || $results[$i]["correctClassId"]==-1){
				// considering correct if the correct class was guessed OR if there was no correct class label
				$correct++;
			}else{
				// considering wrong only if correct class is something else than what user chose
				$wrong++;
			}
			
			if($results[$i]["classId"]==-1){
				// user chose "other" as class. maybe make a list of rejections here in future.
				$unlabeled++;
			}else{
				$labeled++;
				// labeling was done, so we update database
				if($labelingDone==true){
					$query.=",";
				}
				$query.="(".$results[$i]["wordId"].", ".$results[$i]["classId"].")";
				$labelingDone=true;
			}
		}
		$query.=";";
		$score=$correct-$wrong;

		$success = false;
        if (mysqli_query($this->lnk, $query)) {
			$query = "INSERT INTO Labeler_Results (Name, Score, Correct, Wrong,Labeled, Unlabeled) 
				VALUES ('$name', $score, $correct, $wrong,$labeled, $unlabeled);";
			
			if (mysqli_query($this->lnk, $query)) {
				$success   = true;
			}
        }	
		
		
        return array(
            "success" => $success
        );
    }
    
	
	//
	// DELETINGS
	//
	// delete word from the system
	function removeWord($params)
    {
		$word=$params["word"];
		
		$sql = "SELECT `Id` FROM `Labeler_Words` WHERE `Value` = '$word'";
		$rs = mysqli_query ( $this->lnk, $sql);
		
		$words=array();
		if ( mysqli_num_rows( $rs ) != 0){
			$row=mysqli_fetch_row( $rs );
			$id=$row[0];
			
			$sql = "DELETE FROM `Labeler_Words` WHERE `Id` = $id";
			$rs = mysqli_query ( $this->lnk, $sql);
			
			$sql = "DELETE FROM `Labeler_Observations` WHERE `WordId` = $id";
			$rs = mysqli_query ( $this->lnk, $sql);
			
			return array(
				"success" => true
			);
		}
		
		return array(
			"success" => false
		);
	}
	
	// setting all observations for the word to zero
	function resetWord($params)
    {
		$word=$params["word"];
		
		$sql = "SELECT `Id` FROM `Labeler_Words` WHERE `Value` = '$word'";
		$rs = mysqli_query ( $this->lnk, $sql);
		
		$words=array();
		if ( mysqli_num_rows( $rs ) != 0){
			$row=mysqli_fetch_row( $rs );
			$id=$row[0];
			
			$sql = "DELETE FROM `Labeler_Observations` WHERE `WordId` = $id";
			$rs = mysqli_query ( $this->lnk, $sql);
			
			return array(
				"success" => true
			);
		}
		
		return array(
			"success" => false
		);
	}
	
	// delete class from the system
	function removeClass($params)
    {
		$class=$params["class"];
		
		$sql = "SELECT `Id` FROM `Labeler_Classes` WHERE `Value` = '$class'";
		$rs = mysqli_query ( $this->lnk, $sql);
		
		if ( mysqli_num_rows( $rs ) != 0){
			$row=mysqli_fetch_row( $rs );
			$id=$row[0];
			
			$sql = "DELETE FROM `Labeler_Classes` WHERE `Id` = $id";
			$rs = mysqli_query ( $this->lnk, $sql);
			
			$sql = "DELETE FROM `Labeler_Observations` WHERE `ClassId` = $id";
			$rs = mysqli_query ( $this->lnk, $sql);
			
			return array(
				"success" => true
			);
		}
		
		return array(
			"success" => false
		);
	}
	
	//
	// GETTING DATA
	//
	// gets a randomly generated game
    function makeGame($param)
    {
		$size=$param["size"];
		
		
		$getWords=$this->getWords();
		if($getWords["success"]==true){
			$words=$getWords["words"];
		}else{
			return array(
				"success" => false,
				"message" => "no words found"
			);
		}
		
		
		$finalWords=array();
		$intervals=3;
		$confidenceThreshold=0.75;
		for($i=0;$i<min($size,count($words));$i++){
			$left=($i%$intervals)*count($words)/$intervals;
			$right=$left+count($words)/$intervals-1;
			$randomIndex=rand($left, $right);
			//echo $randomIndex." ".$left." ".$right."        \n<br>";
			if($words[$randomIndex]["confidence"]<$confidenceThreshold){
				$words[$randomIndex]["correctClassId"]=-1;
				$words[$randomIndex]["correctClass"]="other";
			}
			array_push($finalWords,$words[$randomIndex]);
		}
		
		
		$classes=$this->getClasses();
		$classes=$classes["classes"];
		
		$finalClasses=array();
		$extra=0;
		for($j=0;$j<count($classes);$j++){
			$ok=false;
			for($i=0;$i<count($finalWords);$i++){
				if($classes[$j]["id"]==$finalWords[$i]["correctClassId"]){
					$ok=true;
					$break;
				}
			}
			if($ok==true){
				array_push($finalClasses,$classes[$j]);
			}else if($extra<1){
				array_push($finalClasses,$classes[$j]);
				$extra++;
			}
		}
		
		if(count($finalWords)>0){
			return array(
				"success" => true,
				"words" => $finalWords,
				"classes" => $finalClasses
			);
		}
		
    }
	
	// gets all the words (given a key)
    function getWords($param)
    {
		$sql = "SELECT `WordId`, `Value`, count(*) as `cnt` 
			FROM `Labeler_Observations` AS t1, `Labeler_Words` AS t2 
			WHERE t1.`WordId`=t2.`Id` GROUP BY `WordId` ORDER BY `cnt`;";
			
		$rs = mysqli_query ( $this->lnk, $sql);
		
		
		$words=array();
		if ( mysqli_num_rows( $rs ) != 0){
			while($row = mysqli_fetch_row( $rs )){
				$word=array();
				$word["id"]=$row[0];
				$word["value"]=$row[1];
				
				$sql = "SELECT t.id, t.value, t.cnt FROM (SELECT a1.ClassId as id, a2.Value as value, count(*) AS `cnt` 
					FROM `Labeler_Observations` AS a1, `Labeler_Classes` AS a2 WHERE a1.ClassId=a2.Id AND a1.WordId =".$word["id"]."
					GROUP BY ClassId) AS t WHERE t.`cnt` IN (
						SELECT (t2.cnt) AS max FROM (
							SELECT ClassId, count(*) AS `cnt` FROM `Labeler_Observations` WHERE WordId =".$word["id"]."
						GROUP BY ClassId )as t2 ORDER BY max 
					) ORDER BY t.cnt DESC;";
					
				
				$rs2 = mysqli_query ( $this->lnk, $sql);
				
				$row2 = mysqli_fetch_row( $rs2 );
				$word["correctClassId"]=$row2[0];
				$word["correctClass"]=$row2[1];
				$frequency=$row2[2];
				
				$row2 = mysqli_fetch_row( $rs2 );
				if($row2!=null){
					$word["confidence"]=($frequency-$row2[2])/$frequency;
				}else{
					$word["confidence"]=min(0.3*$frequency,1);
				}
				
				
				
				
				array_push($words,$word);
			}
		}
		
		
		
		
		$sql = "SELECT `Id`, `Value` FROM `Labeler_Words` 
			WHERE `Id` NOT IN 
			(SELECT DISTINCT `WordId` FROM `Labeler_Observations`);";
			
		$rs = mysqli_query ( $this->lnk, $sql);
		
		if ( mysqli_num_rows( $rs ) != 0){
			while($row = mysqli_fetch_row( $rs )){
				$word["id"]=$row[0];
				$word["value"]=$row[1];
				$word["correctClassId"]=-1;
				$word["correctClass"]="other";
				$word["confidence"]=0;
				
				array_push($words,$word);
			}
		}
		
		
		foreach ($words as $key => $row) {
			$confidence[$key] = $row['confidence'];
		}

		array_multisort($confidence, SORT_DESC, $words);
		
		if(count($words)>=1){
			return array(
				"success" => true,
				"words" => $words
			);
		}
		
		return array(
			"success" => false,
			"message" => "no words found"
		);
    }
	
	// gets all the classes (given a key)
    function getClasses($param)
    {
		$class=$param["class"];
		
		$sql = "SELECT C.`Id`, C.`Value`, count(*) as WordNumber 
			FROM `Labeler_Observations` as O, `Labeler_Classes` as C, `Labeler_Words` as W 
			WHERE O.`WordId`=W.`Id` AND O.`ClassId`=C.`Id` GROUP BY C.`Id` ;";
			
		$rs = mysqli_query ( $this->lnk, $sql);
		
		$classes=array();
		$in="-1";
		if ( mysqli_num_rows( $rs ) != 0){
			while($row = mysqli_fetch_row( $rs )){
				$class["id"]=$row[0];
				$class["value"]=$row[1];
				$class["wordNumber"]=$row[2];
				
				$in.=",".$class["id"];
				array_push($classes,$class);
			}
		}
		
		
		$getWords=$this->getWords();
		if($getWords["success"]==true){
			$words=$getWords["words"];
		}else{
			return array(
				"success" => false,
				"message" => "no words found"
			);
		}
		
		$wordCounts=array();
		$classMapping=array();
		$confidenceThreshold=0.75;
		for($i=0;$i<count($words);$i++){
			if($words[$i]["confidence"]>=$confidenceThreshold){
				if($wordCounts[$words[$i]["correctClassId"]]==null){
					$wordCounts[$words[$i]["correctClassId"]]=0;
				}
				$wordCounts[$words[$i]["correctClassId"]]++;
				$classMapping[$words[$i]["correctClassId"]]=$words[$i]["correctClass"];
			}
		}
		
		$in="-1";
		$classes=array();
		foreach ($wordCounts as $key => $value) {
			$in.=",".$key;
			$class["id"]=$key;
			$class["value"]=$classMapping[$key];
			$class["wordNumber"]=$value;
			array_push($classes,$class);
		}
				
		
		
		$sql = "SELECT `Id`, `Value`  
			FROM `Labeler_Classes` WHERE `Id` NOT IN ($in);";
			
		$rs = mysqli_query ( $this->lnk, $sql);
		
		if ( mysqli_num_rows( $rs ) != 0){
			while($row = mysqli_fetch_row( $rs )){
				$class["id"]=$row[0];
				$class["value"]=$row[1];
				$class["wordNumber"]=0;
				
				array_push($classes,$class);
			}
		}
		
		
		if(count($classes>0)){
			return array(
				"success" => true,
				"classes" => $classes
			);
		}
			
		return array(
			"success" => false,
			"message" => "no classes found"
		);
    }
	
	// gets all the scores (given a key)
    function getResults($param)
    {
		$name=$param["name"];
		
		$sql = "SELECT `Name`, `Score`, `Correct`, `Wrong`, `Labeled`, `Unlabeled` 
			FROM `Labeler_Results` WHERE `Name` LIKE '%$name%'";
			
		$rs = mysqli_query ( $this->lnk, $sql);
		
		$results=array();
		if ( mysqli_num_rows( $rs ) != 0){
			while($row = mysqli_fetch_row( $rs )){
				$result["name"]=$row[0];
				$result["score"]=$row[1];
				$result["correct"]=$row[2];
				$result["wrong"]=$row[3];
				$result["labeled"]=$row[4];
				$result["unlabeled"]=$row[5];
				
				array_push($results,$result);
			}
			return array(
				"success" => true,
				"results" => $results
			);
		}
		
		return array(
			"success" => false,
			"message" => "no results found"
		);
    }
	
}
?>